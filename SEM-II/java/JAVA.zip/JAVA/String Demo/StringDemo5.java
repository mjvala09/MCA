class StringDemo5{
	public static void main(String[] args) {
		String str = "Hello All, How are you? I hope you all are fine and well...";

		System.out.println(str.substring(5,10));

		String str1 = "Jack & Jue";
		System.out.println(str1);		
		System.out.println(str1.replace("J","Bl"));		

		System.out.println(str.charAt(8));				
	}
}