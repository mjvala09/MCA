package same;
public class A{
	public int a = 10;
	public int b = 20;
	protected int c = 30;
	public int d = 40;
}