class WrapperDemo3{
	public static void main(String[] args) {
		Integer iObj = 500;
		int i = iObj; // UnBoxing
		System.out.println(i);
	}
}