package com.example.thebigbull

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.TimePicker
import java.util.Calendar

class SignInActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        var submit_signin = findViewById<Button>(R.id.button)
        var validEmail = findViewById<EditText>(R.id.validEmail)
        var check_box = findViewById<CheckBox>(R.id.checkBox)

        submit_signin.isEnabled = false
        check_box.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener{
            override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {
                if(check_box.isChecked == true){
                    submit_signin.isEnabled = true
                }else{
                    submit_signin.isEnabled = false
                }
            }
        })

        validEmail.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(p0).matches()) {
                    validEmail.setError("Valid Email")
                }
            }
            override fun afterTextChanged(p0: Editable?) {
            }
        })

        var set_date = findViewById<EditText>(R.id.editTextDate2)
        var set_time = findViewById<EditText>(R.id.editTextTime)
        var c = Calendar.getInstance()

        set_time.setOnClickListener {
            TimePickerDialog(this, TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                set_time.setText("$hour : $minute")
            },c.get(Calendar.HOUR),c.get(Calendar.MINUTE),true).show()
        }

        set_date.setOnClickListener {
            DatePickerDialog(this,DatePickerDialog.OnDateSetListener { datePicker, year, month, day ->
                set_date.setText("$day/${month + 1}/$year")
            },c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }


    }
}